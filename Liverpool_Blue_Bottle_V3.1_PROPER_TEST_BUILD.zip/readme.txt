Liverpool Blue Bottle Liquor Express — V3.1 TEST BUILD

SOURCE
Built directly from the uploaded V3.0 package. This is an improvement build,
not a reconstruction from memory.

V3.1 IMPLEMENTED
- Official supplied Liverpool Blue Bottle circular logo in the top-left header.
- Official supplied Liverpool Blue Bottle banner in the hero.
- Official supplied blue/white WhatsApp icon used for WhatsApp website elements.
- WhatsApp icon replaces the previous green-dot treatment.
- Simplified desktop/mobile navigation: Home, Current Specials, Find Us, WhatsApp.
- Categories remains available as the on-page category strip, not as a hamburger item.
- Removed the blue "COME SEE US" eyebrow from the Find Us section.
- Kept the large white "Find Us" heading.
- Product rows remain touch/swipe carousels with snap behaviour.
- Only product/category rows can move horizontally; the whole page cannot.
- Mobile product cards remain large and reveal part of the next card.
- Existing V3.0 product data/prices/content are preserved.
- No AI-generated or invented bottle images have been added.
- No cart, checkout, accounts, wholesale or other future features were added.

OFFICIAL ASSETS
assets/liverpool-blue-bottle-logo.jpg
assets/liverpool-blue-bottle-banner.jpg
assets/whatsapp-icon.png

The WhatsApp source image had a checkerboard around the circular icon. The
checkerboard was removed only from the surrounding area so the supplied icon
displays cleanly on the website. The icon itself was not redesigned.

STATUS
V3.1 TEST BUILD. Deploy to Netlify and test on the phone before treating it
as final. Any issues found after deployment become the V3.2 test/fix list.
