Liverpool Blue Bottle Liquor Express — V3.1 TEST BUILD

Source:
- Built directly from the supplied V3.0 deployed/known-good package.
- No reconstruction from memory.

V3.1 focus:
- Responsive hero/banner asset support.
- Supplied BB logo asset support.
- Current Specials retained; Featured Specials not introduced.
- Touch-first product carousels with snap behavior.
- Mobile cards show part of the next card to encourage swiping.
- Only product rows scroll horizontally; page remains horizontally locked.
- Stable product image handling and lazy/deferred decoding where appropriate.
- Simplified navigation.
- FIND US wording and responsible-drinking wording.
- Supplied WhatsApp icon asset support.
- No cart, checkout, accounts, wholesale, or full catalogue added.

Asset locations expected:
- assets/bb-logo.png
- assets/hero-banner.jpg
- assets/whatsapp-icon.png

If those assets are not present in the deployment package, the site retains its existing visual fallback rather than inventing/AI-altering product imagery.

STATUS:
TEST BUILD — deploy to Netlify and test on phone before calling V3.1 final.
