Liverpool Blue Bottle Liquor Express — V3
Built from the 8 August deployed Netlify package.

This version focuses on the agreed mobile-first structure:
- simplified hero
- Current Specials hierarchy
- swipeable product category rows
- no Featured Specials
- no floating Call button
- Join WhatsApp in navigation
- Find Us + Trading Hours + Google Maps
- subtle scroll polish
- no cart, checkout or accounts

IMPORTANT:
The real banner/product image assets are not present in the supplied 8 August ZIP.
The hero therefore uses an original CSS promotional placeholder until the selected
Liverpool Blue Bottle banner and real bottle photos are added.
