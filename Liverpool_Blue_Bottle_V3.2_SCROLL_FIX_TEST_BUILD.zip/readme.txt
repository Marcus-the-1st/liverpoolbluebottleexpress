Liverpool Blue Bottle Liquor Express — V3.2 TEST BUILD

SOURCE
Built directly from the verified V3.1 proper test build.

TEST FEEDBACK ADDRESSED
1. Mobile page vertical scrolling was not reliably registering when a finger
   started over a product/category horizontal scrolling area.
   - Changed carousel touch handling from horizontal-only to pan-x pan-y.
   - Vertical finger movement can now scroll the page normally.
   - Horizontal finger movement can still scroll the carousel.

2. Back-to-top control appeared visually boxy/incorrect in testing.
   - Reworked the existing control as a compact, clean 46px circular button.
   - Removed default browser button appearance.
   - Kept the existing smooth scroll-to-top function.

IMPORTANT
- Official Liverpool Blue Bottle logo: unchanged.
- Official Liverpool Blue Bottle banner: unchanged.
- Official blue/white WhatsApp icon: unchanged.
- No product imagery was changed.
- No unrelated website sections were redesigned.

STATUS
V3.2 TEST BUILD — deploy and test on the phone.
If scrolling now behaves correctly and the back-to-top button looks normal,
those items can be marked fixed. Any remaining issues become the next test list.
